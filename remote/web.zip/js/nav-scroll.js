ScrollOut({
  cssProps: true,
  threshold: 0.2
});