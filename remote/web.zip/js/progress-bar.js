/*$("#resetBarBtn").click(function() {
	$('.shrinker').removeClass('timelapse');
	setTimeout(function() {
		$('.shrinker').addClass('timelapse');
	}, 500)
})*/

//make the timelapse reset each 10 seconds
setInterval(function() {
	$('.shrinker').removeClass('timelapse');
	setTimeout(function() {
		$('.shrinker').addClass('timelapse');
	}, 0)
} , 10000);